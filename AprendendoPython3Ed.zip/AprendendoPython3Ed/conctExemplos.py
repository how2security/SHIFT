#!/usr/bin/env python3
# -*- coding: utf-8 -*-

print("Concatenação Lenta -> L = L + [3]")
L = [1, 2]
L = L + [3]
print(L)

print("Concatenação mais rápida -> L.append(4)")
L.append(4)
print(L)

# Adicionar um conjunto de itens no final
print("Concatenação Lenta -> L = L + [5, 6]")
L = L + [5, 6]
print(L)

print("Concatenação mais rápida -> L.extend([7, 8])")
L.extend([7, 8])
print(L)

print("Ao utilizar a atribuição para estender uma lista, o Python chama automaticamente o método mais rápido extend, em vez da operação de concatenação mais lenta indicada por + -> L += [9, 10]")
L += [9, 10]
print(L)