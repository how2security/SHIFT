#!/usr/bin/env python3
# -*- coding: utf-8 -*-

for x in ["spam", "eggs", "ham"]:
   print(x)
  
sum = 0
for x in [1, 2, 3, 4]:
   sum = sum + x
sum

prod = 1
for item in [1, 2, 3, 4]: prod *= item
prod

'''
   Vamos ver algo um pouco mais sofisticado. O próximo exemplo ilustra a cláusula else em um loop for e o caminho de instruções.
   Dada uma lista de objetos (itens) e uma lista de chaves (tests), este código pesquisa cada chave na lista de objetos e relata o resultado da pesquisa.
'''
itens = ['aaa', 111, (4, 5), 2.0]		# Um conjunto de objetos
tests = [(4, 5), 3.14]					# Chaves para pesquisar

for key in tests:						# Para todas as chaves
   for item in itens:					# Para todos os itens
      if item == key:					# Verifica a correspondência
	     print(key, "was found")
		 break
	else:
	   print(key, "not found!")

'''
   A próposito, esse exemplo será mais fácil de escrever se empregramos o operador in para testar participação como membro. Como o operador in percorre uma lista implicitamente, em busca de uma correrspondência, ele substitui o loop interno:
'''

for key in tests:						# Para todas as chaves
   if key in itens:						# Deixa o Python procurar uma correspondência
      print(key, "was found")
   else:
      print(key, "not found!")
	  
'''
   Executaremos uma tarefa típica de estrutura de dados com um loop for - coletar itens comuns em duas sequências (strings). É mais ou menos uma rotina de interseção de conjuntos simpkles; após a execução do loop, res refere-see a uma lista que contém todos os itens em seq1 e em seq2.
'''

seq1 = "spam"
seq2 = "scam"
res = []								# Comça vazio

for x in seq1:							# Percorre a primeira sequências
   if x in seq2							# Item comum?
      res.append(x)						# Adicionar no final do resultado

'''
   Utilizando a função range() para iterar por x vezes
'''
for i in range(5):
   print(i, "- Python")

'''
   Internamente, o loop for terata dos detalhes da iteração automaticamente. Se você precisar realmente assumir explicitamente o controle da lógica de indexação, pode fazer isso com um loop while:
'''

X = 'spam'
for item in X: print(item)

i = 0
while i < len(X):							# iteração do loop while
   printX[i],; i += 1
	  
for i in range(len(X)): print(X[i])			# Indexação de loop for manual

for i in range(0, len(X), 2): print(X[i])	# Indexação de loop for manual saltando de 2 em 2
for x in X[::2]: print(x)					# Através de fracionamento conseguimos o mesmo resultado

L = [0, 1, 2, 3, 4]
for i in range(len(L)):
   L[i] += 1
L

i = 0
while i < len(L):
   L[i] += 1
   i += 1
L

'''
   Em geral, os loops são uteis em qualquer lugar onde você precise repetir ou processar algo mais de uma vez. Como os arquivos contêm vários caracteres e linhas, eles são um dos usos mais típicos para os loops. Para carregar todos o conteúdo de um arquivo em uma string, de uma só vez, você simplesmente chama a instrução read:
'''

file = open('test.txt', 'r')
print(file.read())
file.close()

'''
   Iterando com listas combinadas com a função zip()
'''
L1 = [1, 2, 3, 4]
L2 = [5, 6, 7, 8]

for (x,y) in zip(L1, L2):
   print(x, '+', y '=', x+y)

'''
   Os dicionários sempre podem ser criados escrevendo um literal de dicionário ou pela atribuição de chaves com o passar do tempo:
'''

D1 = {'spam' : 1, 'eggs' : 3, 'toast' : 5}

'''
   Contudo, o que fazer se seu programa recebe chaves e valores de dicionário em lista em tempo de execução, após você ter escrito seu script?
'''
keys = ['spam', 'eggs', 'toast']
vals = [1, 2, 3]

list(zip(keys, vals))

D2 = {}
for (k, v) in zip(keys, vals): D2[k] = v

D2

D3 = dict(zip(keys, vals))
D3
   
'''
   Mas para carregar um arquivo por partes, é comum escrever um loop while com instruções break no final do arquivo ou um loop for. Para ler por caracteres:
'''

file = open('test.txt')
while 1:
   char = file.read(1)			# Lê por caractere
   if not char: break
   print(char)

file.close()
   
   
for char in open('test.txt').read():
   print(char)

file.close()

'''
   O loop for aqui também processa cada caractere, mas carrega o arquivo na memória, todo de uma vez. Para ler por linha ou blocos com um loop while:
'''

file = open('test.txt')
while 1:
   line = file.readline()	# Lê linha por linha
   if not line: break
   print line
file.close()

file = open('test.txt', 'rb')
while 1:
   chunk = file.read(10)	# Lê trechos de bytes
   if not chunk: break
   print(chunk)
file.close()

'''
   Contudo, para ler arquivos de texto linha por linha, o loop for tende ser mais fácil de escrever e mais rápido para executar:
'''
for line in open('test.txt').readlines(): print(line)	# Carrega o arquivo todo de uma vez em uma lista de string de linha
for line in open('test.txt').xreadlines(): print(line)	# Carrega as linhas de acordo com a demanda, para não encher a memória no caso de arquivos grandes
for line in open('test.txt'): print(line)