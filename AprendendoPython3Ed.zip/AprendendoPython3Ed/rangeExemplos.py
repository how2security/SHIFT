#!/usr/bin/env python3
# -*- coding: utf-8 -*-

'''
  Range de zero até, mas não incluso, 5
'''
list(range(5))

'''
   Range iniciando em 5 até, mas não incluso, 10
'''
list(range(5, 10))

'''
   Range iniciando em zero até, mas não incluso, 10 saltando de 2 em 2
'''
list(range(0, 10, 2))

'''
   Range iniciando em um número negativo
'''
list(range(-5, 5))

'''
   Range em ordem descendente
'''
list(range(5, -5, -1))
list(range(5, -1, -1))

