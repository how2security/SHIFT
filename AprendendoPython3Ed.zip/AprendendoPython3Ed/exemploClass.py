class Super:
    def method(self):
        print('in Super.method')        # Comportamento padrão
    def delegate(self):
        self.action()                   # Esperando para ser definido

class Inheritor(Super):                 # Método herdadi literalmente.
    pass

class Replacer(Super):                  # Substitui o método completamente
    def method(self):
        print('in Replacer.method')

class Extender(Super):                  # Estende o comportamento de method
    def method(self):
        print('starting Extender.method')
        Super.method(self)
        print('ending Extender.method')

class Provider(Super):                  # Preenche um método exigido
    def action(self):
        print('in Provider.action')

if __name__ == '__main__':
    for klass in (Inheritor, Replacer, Extender):
        print('\n' + klass.__name__ + '...')
        klass().method()

    print('\nProvider...')
    x = Provider()
    x.delegate()