#!/usr/bin/env python3
# -*- coding: utf-8 -*-

'''
   Esse loop apenas imprime uma mensagem para sempre, aninhando uma função print em um loop while. Lembre-se de que um alor inteiro 1 significa verdadeiro; como o teste é sempre verdadeiro, o Python continua executando o miolo para sempre ou até que você interrompa sua execução. Normalmente esse tipo de comportamento é chamado de loop infinito.
'''

while 1:
   print("Type CTRL+C to stop me!")

'''
   O próximo exemplo fica fracionando o primeiro caractere de uma string, até que a string esteja vazia e, portanto, falsa.
   É comum testar um objeto diretamente dessa forma, em vez de usar o equivalente mais longo:
   
   while x != ' ':
'''

x = 'spam'

while x:
   print(x)
   x = x[1:]

'''
   O código a seguir conta do valor de A até (mas não incluindo) B.
'''

A = 0; B = 10
while A < B:
   print(A)
   A += 1

'''
   A instrução pass é usada quando a sintaxwe exige uma instrução, mas você não tem nada de útil a fazer. Por exemplo, se você quiser escrever um loop infinito que não faça nada sempre que for percorrido, utilize a instrução pass:
'''

while 1: pass	# Digite CTERL+C para interromper

'''
   A instrução continue é um salto imediado para o início de um loop. As vezes ela permite que você evite o aninhamento de instruções. O próximo exemplo usa continue para pular números ímpares. Esse código imprime todos os números pares menores do que 10 e menores ou iguais a 0.
   Lembre-se de que 0 (zero) significa falso e % é o operador de resto de divisão; portantom, esse loop conta regressivamente até zero, pulando os números que não são múltiplos de dois.
'''

x = 10
while x:
   x = x - 1
   if x % 2 != 0: continue
   print(x)

   '''
      Como a instrução continue pula para o início do loop, você não precisa aninhar a instrução print dentro de um teste if, a instrução print só é alcançada se a instrução continue não é executada. Essa instrução deve ser pouco usada, pois, ela é bem parecida com as instruções goto de outras linguagens. O ideal mesmo seria fazer o seguinte:
   '''

x = 10
while x:
   x = x- 1
   if x % 2 == 0:		# Par? imprime
      print(x)

'''
   Vamos criar um loop interativo. Esse loop só irá parar quando receber o nome "stop"
'''

while 1:
   name = raw_input('Enter name: ')
   if name == 'stop': break
   age = raw_input('Enter age: ')
   print("Hello ', name, '=>', int(age)** 2

# raw_input() em Python 2.x e apenas input() em Python3

y = int(input('Valor: '))
x = y / 2
while x > 1:
   if y % x == 0:
      print(y, 'has factor', x)
	  break
   x = x - 1
else:
   print(y, 'is prime')
   
'''
   Vamos supor que você queira escrever um loop para procurar um valor em uma lista e precise saber se o valor foi encontrado após sair do loop.
'''
x = [0, 1, 2, 3]
found = 0
while x and not found:
   if match(x[0]):		# Valor está no início
      print("Ni")
	  found = 1
   else:
      x = x[1:]			# Fraciona o início e repete
if not found:
   print("Not Found")

'''
   Em geral, os loops são uteis em qualquer lugar onde você precise repetir ou processar algo mais de uma vez. Como os arquivos contêm vários caracteres e linhas, eles são um dos usos mais típicos para os loops. Para carregar todos o conteúdo de um arquivo em uma string, de uma só vez, você simplesmente chama a instrução read:
'''

file = open('test.txt', 'r')
print(file.read())
file.close()

'''
   Mas para carregar um arquivo por partes, é comum escrever um loop while com instruções break no final do arquivo ou um loop for. Para ler por caracteres:
'''

file = open('test.txt')
while 1:
   char = file.read(1)			# Lê por caractere
   if not char: break
   print(char)

file.close()
   
   
for char in open('test.txt').read():
   print(char)

file.close()

'''
   O loop for aqui também processa cada caractere, mas carrega o arquivo na memória, todo de uma vez. Para ler por linha ou blocos com um loop while:
'''

file = open('test.txt')
while 1:
   line = file.readline()	# Lê linha por linha
   if not line: break
   print line
file.close()

file = open('test.txt', 'rb')
while 1:
   chunk = file.read(10)	# Lê trechos de bytes
   if not chunk: break
   print(chunk)
file.close()

'''
   Contudo, para ler arquivos de texto linha por linha, o loop for tende ser mais fácil de escrever e mais rápido para executar:
'''
for line in open('test.txt').readlines(): print(line)	# Carrega o arquivo todo de uma vez em uma lista de string de linha
for line in open('test.txt').xreadlines(): print(line)	# Carrega as linhas de acordo com a demanda, para não encher a memória no caso de arquivos grandes
for line in open('test.txt'): print(line)



