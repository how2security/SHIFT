#!/usr/bin/env python3
# -*- coding: utf-8 -*-

def times(x, y):		# Cria e atribui função
   return x * y 		# Corpo executado quando chamado

print(times(2, 4))		# Chama a função times() passando os argumentos entre os parenteses

x = times(3.14, 4)		# Salva o objeto resultado
print(x)

y = times('Ni', 4)		# As funções são "sem tipos"
print(y)

'''
   Aqui a função recebe duas variáveis e recebe de volta uma lista contendo os caracteres em comum
'''
def intersect(seq1, seq2):
   res = []				# Começa vazio
   for x in seq1:		# Percorre seq1
      if x in seq2:		# Item comum?
	     res.append(x)	# Adiciona no fim
   return res
   
s1 = "SPAM"
s2 = "SCAM"

print(intersect(s1, s2))			# Strings
x = intersect([1, 2, 3], (1, 4))	# Tipos misturados
print(x)							# Objeto resultado salvo

'''
   A solução de nome do Python às vezes é chamada de regra LEGB, por causa dos nomes de escopo: Quando você usa um nome qualificado dentro de uma função, o Python pesquisa para cima em quatro escopos - o Local (L), depois o escopo local de quaisquer instruções def e lambda envolventes (E), em seguida o global (G) e, então, o interno (B, de Built-in) - e pára no primeiro lugar onde o nome foi encontrado. Se ele não for encontrado durantre essa pesquisa, o Python relatará um erro.
'''

# Escopo global
X = 99					# X e func atribuídos no módulo: globais

def func(Y):			# Y e Z atribuídos na função: locais
   # Escopo local
   Z = X + Y			# X é global
   return Z

func(1)					# func no módulo: resultado = 100

'''
   A instrução global é apenas a palavra-chave global, seguida por um ou mais nomes, separados por vírgulas. Poer exemplo:
'''
X = 88				# X global

def func():
   global X			# X global: fora de def
   X = 99
func()
print(X)			# Imprime 99 e não 88 já que alteramos ela dentro da função func()

'''
   Aqui x, y e z são todas globais dentro da função all_global(). y e z globais porque não são atribuídas na função; x é global porque foi listada em uma instrução global para fazer seu mapeamento para o escopo do módulo explicitamente. Sem a instrução global aqui, x seria considerada local, graças à atribuição.
'''

y, z = 1, 2

def all_global():
   global x
   x = y + z

all_global()
print(y, '+', z, '=', x)

'''
   Exemplo de escopo aninhado (a letra "E" da regra de pesquisa LEGB).
'''

de f1():
   x = 88
   def f2():
      print(x)
   f2()

f1()

def f1():
   x = 88
   def f2():
      print(x)
   return f2
	  
action = f1()
action()

'''
   Depois que uma instrução def é executada, o nome da função é uma referência para um objeto.
   Você pode atribuir esse objeto novamente para outros nomes e chama-los por meio de qualquer referência - e não apenas pelo nome original.
'''

def echo(message):	# Echo atribuído a um objeto função
   print(message)

# x = echo			# Agora x faz referência a ele também
# x('Hello world')	# Chama o objeto adicionado ()

'''
   Como os argumentos são passados pela atribuição de objetos, é fácil passar funções para outras funções, como argumentos. Quem é chamado pode, então, chamar a função passada apenas adicionando argumentos entre parênteses:
'''

def inderect(func, arg):
   func(arg)	# Chama os objetos adicionados ().
   
# indirect(echo, 'Hello jello!')	# Passa função para uma função

'''
   Você pode até colocar objetos função em estruturas de dados, como se eles fossem inteiros ou strings. Como os tipos compostos do Python podem conter qualquer tipo de objeto, tambémn não há nenhum caso wespecial aqui.
'''

schedule = [ (echo, 'Spam!'), (echo, "Ham!") ]
for (func, arg) in schedule:
   func(arg)
   

