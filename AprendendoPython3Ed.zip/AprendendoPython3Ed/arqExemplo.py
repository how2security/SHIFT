#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# C:\Users\a80581592\AppData\Local\Programs\Python\Python36-32

myfile = open('myfile', 'w')		# Abre para saída (cria).
myfile.write('helo text file\n')	# Grava uma linha de texto
myfile.close()						# Fechando o arquivo

myfile = open('myfile', 'r')		# Abre para entrada
myfile.readline()					# Lê a linha de volta
myfile.readline()					# String vazia: fim do arquivo

'''
   Em geral, os loops são uteis em qualquer lugar onde você precise repetir ou processar algo mais de uma vez. Como os arquivos contêm vários caracteres e linhas, eles são um dos usos mais típicos para os loops. Para carregar todos o conteúdo de um arquivo em uma string, de uma só vez, você simplesmente chama a instrução read:
'''

file = open('test.txt', 'r')
print(file.read())
file.close()

'''
   Mas para carregar um arquivo por partes, é comum escrever um loop while com instruções break no final do arquivo ou um loop for. Para ler por caracteres:
'''

file = open('test.txt')
while 1:
   char = file.read(1)			# Lê por caractere
   if not char: break
   print(char)

file.close()
   
   
for char in open('test.txt').read():
   print(char)

file.close()

'''
   O loop for aqui também processa cada caractere, mas carrega o arquivo na memória, todo de uma vez. Para ler por linha ou blocos com um loop while:
'''

file = open('test.txt')
while 1:
   line = file.readline()	# Lê linha por linha
   if not line: break
   print line
file.close()

file = open('test.txt', 'rb')
while 1:
   chunk = file.read(10)	# Lê trechos de bytes
   if not chunk: break
   print(chunk)
file.close()

'''
   Contudo, para ler arquivos de texto linha por linha, o loop for tende ser mais fácil de escrever e mais rápido para executar:
'''
for line in open('test.txt').readlines(): print(line)	# Carrega o arquivo todo de uma vez em uma lista de string de linha
for line in open('test.txt').xreadlines(): print(line)	# Carrega as linhas de acordo com a demanda, para não encher a memória no caso de arquivos grandes
for line in open('test.txt'): print(line)

