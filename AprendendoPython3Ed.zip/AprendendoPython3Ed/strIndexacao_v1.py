#!/usr/bin/env python3
# -*- coding: utf-8 -*-

print("INDEXAÇÃO")
print("-" * 9)

S = 'spam'

print("[0] [1] [2] [3]")
print"([:           :]")
print(" s   p   a  m")
print("[0][-3][-2][-1]")

print("Deslocamento positivo")
print("Index S[0] = %s" % S[0])
print("Index S[0] = %s" % S[1])
print("Index S[0] = %s" % S[2])
print("Index S[0] = %s" % S[3])

print("Deslocamento negativo")
print("Index S[-1] = %s" % S[-1])
print("Index S[-2] = %s" % S[-2])
print("Index S[-3] = %s" % S[-3])

