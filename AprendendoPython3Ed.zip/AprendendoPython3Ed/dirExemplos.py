#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
dir(sys)

dir([]), dir(list)

dir(' '), dir(str)



