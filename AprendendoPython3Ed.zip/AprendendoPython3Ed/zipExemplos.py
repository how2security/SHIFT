#!/usr/bin/env python3
# -*- coding: utf-8 -*-


'''
   Para combinar os itens dessas listas, podemos usar a função zip:
'''
L1 = [1, 2, 3, 4]
L2 = [5, 6, 7, 8]

list(zip(L1, L2))

T1, T2, T3 = (1, 2, 3), (4, 5, 6), (6, 7, 8)

list(zip(T1, T2, T3))

'''
   A função zip trunca as tuplas resultantes no comprimento das sequência mais curta, quando os comprimentos dos argumentos diferem:
'''
S1 = 'abc'
S2 = 'efg123'

list(zip(S1, S2))

'''
   A relacionada e mais antiga função interna map cria pares de itens de sequências de maneira semelhante, mas preenche as sequências mais curtas com None, caso comprimentos dos argumentos sejam diferentes:
'''
list(map(None, S1, S2))