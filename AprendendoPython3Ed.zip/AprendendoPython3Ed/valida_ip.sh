#!\bin\bash

#
# Funcao para validacao de ip's (IPv4) - Versao Bash
#
# Sandro Marcell <sandro_marcell@yahoo.com.br>
# Boa Vista, Roraima - 25/10/2009
#
# Esta funcao toma como base a 'RFC 1918' que especifica quais as faixas de
# ip's devem ser usadas numa rede privada. Segundo ela as faixas disponiveis
# para tal fim sao:
# -> 10.0.0.0 - 10.255.255.255
# -> 172.16.0.0 - 172.31.255.255
# -> 192.168.0.0 - 192.168.255.255
# Portanto esta funcao so validara ip's que estejam numa das faixas acima.
#
# Para utiliza-la basta passar como argumento o ip a ser validado e posteriormente
# checar o codigo de retorno ($?) da funcao, em que:
# 0 = ip valido
# 1 = ip invalido
#
# Obs.:
# - Funcao criada sob o bash-3.2.39
# - Mais detalhes: 'man bash' e 'http://tools.ietf.org/html/rfc1918'
# - Funcao passivel de melhorias! ;)


# https://stackoverflow.com/questions/13777387/check-for-ip-validity

#
ValidaIP() {
   local numero_ip=$1

   # Suporte 'built-in' a ER's! legal... =)
   [[ $numero_ip =~ ^[0-9]{2,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]] || return 1
   
   local primeiro_octeto segundo_octeto terceiro_octeto quarto_octeto
   
   OLD_IFS=$IFS
   IFS="."
   
   set - $numero_ip 
   primeiro_octeto=$1
   segundo_octeto=$2
   terceiro_octeto=$3
   quarto_octeto=$4
   
   IFS=$OLD_IFS
   
   # Checa o 2o octeto especifico de cada faixa
   case $primeiro_octeto in
      10)  [[ $segundo_octeto =~ ^0[0-9][0-9]? ]] && return 1 # Invalida tipos '0x' ou '0xx'
           (( segundo_octeto >= 0 && segundo_octeto <= 255 )) || return 1 ;;
      172) (( segundo_octeto >= 16 && segundo_octeto <= 31 )) || return 1 ;;
      192) (( segundo_octeto == 168 )) || return 1 ;;
      *) return 1
   esac
   
   # Ja que o 3o e 4o octetos sao comuns as tres faixas
   [[ $terceiro_octeto =~ ^0[0-9][0-9]? ]] || [[ $quarto_octeto =~ ^0[0-9][0-9]? ]] && return 1
   (( terceiro_octeto >= 0 && terceiro_octeto <= 255 )) || return 1
   (( quarto_octeto >= 0 && quarto_octeto <= 255 )) || return 1

}

ou
if echo "$ip" | { IFS=. read a b c d e;
    test "$a" -ge 0 && test "$a" -le 255 &&
    test "$b" -ge 0 && test "$b" -le 255 &&
    test "$c" -ge 0 && test "$c" -le 255 &&
    test "$d" -ge 0 && test "$d" -le 255 &&
    test -z "$e" \
    2> /dev/null; }; then echo is valid; fi
	
ou 

#!/bin/bash

# Test an IP address for validity:
# Usage:
#      valid_ip IP_ADDRESS
#      if [[ $? -eq 0 ]]; then echo good; else echo bad; fi
#   OR
#      if valid_ip IP_ADDRESS; then echo good; else echo bad; fi
#
function valid_ip()
{
    local  ip=$1
    local  stat=1

    if [[ $ip =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]]; then
        OIFS=$IFS
        IFS='.'
        ip=($ip)
        IFS=$OIFS
        [[ ${ip[0]} -le 255 && ${ip[1]} -le 255 \
            && ${ip[2]} -le 255 && ${ip[3]} -le 255 ]]
        stat=$?
    fi
    return $stat
}

ou

#!/usr/bin/env bash

ip=${1:-1.2.3.4}

ipvalid() {
  # Set up local variables
  local ip=${1:-1.2.3.4}
  local IFS=.; local -a a=($ip)
  # Start with a regex format test
  [[ $ip =~ ^[0-9]+(\.[0-9]+){3}$ ]] || return 1
  # Test values of quads
  for quad in {0..3}; do
    [[ "${a[$quad]}" -gt 255 ]] && return 1
  done
  return 0
}

if ipvalid "$ip"; then
  echo "success ($ip)"
  exit 0
else
  echo "fail ($ip)"
  exit 1
fi

