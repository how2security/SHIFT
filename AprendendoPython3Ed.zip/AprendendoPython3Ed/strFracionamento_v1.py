#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys

print("FRACIONAMENTO")
print("-" * 13)

S = 'spam'
print("S = %s" % S)

print("O limite superior eh nao incluso")
print("Os limites do fracionamento terao 0 e o comprimento da sequencia como padrao, se forem omitidos")
print("S[1:3] => busca do deslocamento 1 ate, mas nao incluindo, 3")
print(S[1:3])

print("S[1:] => busca do deslocamento 1 ate o fim (comprimento)")
print(S[1:])

print("S[:3] => busca do deslocamento 0 ate, mas nao incluindo, 3")
print(S[:3])

print("S[:-1] => busca do deslocamento 0 ate, mas nao incluindo, o ultimo item")
print(S[:-1])

print("S[:] => busca do deslocamento 0 ate o fim - uma copia de nivel superior de S")
print(S[:])

print("S[::-1] => inverte o valor da string")
print(S[::-1])

print("Argumentos a partir do argv[0] => %s" % (sys.argv))
print("Removendo o nome do App (argv[0] => %s" % (sys.argv[1:]))