#!/usr/bin/env python3
# -*- coding: utf-8 -*-

'''
   Documentação do módulo
   As palavras ficam aqui
'''

spam = 40

def square(x):
   '''
      Documentação da função square()
	  podemos ter seu fígado então?
   '''
   
   return x ** 2

class Employee:
   '''
      Documentação da Classe Employee
   '''
   pass

print(square(4))
print(square.__doc__)