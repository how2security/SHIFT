#!/usr/bin/env python3
# -*- coding: utf-8 -*-

'''
   A função zip trunca as tuplas resultantes no comprimento das sequência mais curta, quando os comprimentos dos argumentos diferem:
'''
S1 = 'abc'
S2 = 'efg123'

zip(S1, S2)

'''
   A relacionada e mais antiga função interna map cria pares de itens de sequências de maneira semelhante, mas preenche as sequências mais curtas com None, caso comprimentos dos argumentos sejam diferentes:
'''
map(None, S1, S2)