#!/usr/bin/env python
# -*- coding: utf-8 -*-

a = 3
b = 4

print(a + 1, a -1)
print(b * 3, b / 2)
print(a % 2, b ** 2)
print(2 + 4.0, 2.0 ** b)
print(b / 2 + a)
print("Precedencia: %s" % (b / (2.0 + 3)))
print("Precedencia: %s" % (b / (2.0 + a)))
print("Formatação: %e" % (b / (2.0 + 3)))
print("Formatação: %2.2f" % (b / (2.0 + 3)))
x = 1
print("Bitwase -> x = 1")
print("Deslocando 2 bits para esquerda de um 0001 << 2 = 0100 = %s" % (x << 2))
print("OU Lógico x | 2 = 0001 OU 0010 = 0011 = %s" % (x | 2))
print("E Lógico x & 1 = 0001 E 0001 = 0001 = %s" % (x | 1))
octal = 010 # Versão Python 2.x
hexa = 0x1F
print("Temos um octal (%s) e um hexadecimal (%s)" % (ocatal, hexa))
octal = 0o10 # Versão 3.x
hexa = 0x1F
binario = 0b110 # Versão 3.x
print("Temos binário (%s), octal (%s) e um hexadecimal (%s)" % (binario, octal, hexa))
print("Temos binário (%s), octal (%s) e um hexadecimal (%s)" % (bin(binario), oct(octal), hex(hexa)))
print("Temos binário (%s), octal (%s) e um hexadecimal (%s)" % (int('0100'), int('0100', 8), int('0xaF' 16)))
print("Conversão com a formatacao %0 %x %X" % (64, 64, 255)))



