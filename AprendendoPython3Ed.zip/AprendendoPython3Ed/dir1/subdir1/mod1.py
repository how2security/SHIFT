# Arquivo: dir1\subdir1\mod1.py
print("in mod1")
z = 3
