# Arquivo: dir1\subdir1\__init__.py
print("subdir1 init")
y = 2
