# Arquivo: dir1\__init__.py
print("dir1 init")
x = 1
