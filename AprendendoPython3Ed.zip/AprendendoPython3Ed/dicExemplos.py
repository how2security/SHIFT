#!/usr/bin/env python3
# -*- coding: utf-8 -*-

print("Faz um dicionario => D2 = { 'spam':2, 'ham':1, 'eggs':3}")
D2 = { 'spam':2, 'ham':1, 'eggs':3}
print(D2)
print(D2['spam'])
print("Comprimento => len(D2)")
print(len(D2))
print("Teste de participacao da chave como membro => D2.has_key('ham')")
print(D2.has_key('ham'))
#print('ham' in D2)
print("Teste alternativo de participação da chave como membro => 'ham' in D2")
'ham' in D2
print("Cria uma nova lista de minhas chaves => D2.keys()")
print(D2.keys())
print("Alterando => D2['ham'] = ['grill', 'bake', 'fly']")
D2['ham'] = ['grill', 'bake', 'fly']
print(D2)
print("Exluindo => del D2['eggs']")
del D2['eggs']
print(D2)
print("Adicionando nova entrada => D2['brunch'] = 'bacon'")
D2['brunch'] = 'bacon'
print(D2)
print("Mostrando os valores do dicionario => D2.values()")
print(D2.values())
print("Mostrando todos os itens => D2.items()")
print(D2.items())
print("Pegando os valores com o metodo get()")
print(D2.get('spam'))
print(D2.get('toast'))
print(D2.get('toast', 88))
print("Atualizando com o metodo upadate() => D2.update(D3)")
D3 = { 'toast':4 , 'muffin':5 }
D2.update(D3)
print(D2)
print("Criando uma tabela")
table = { 'Python': 'Guido van Rossum',
        'Perl': 'Larry Wall',
        'Tcl': 'John Ousterhout' }
language = 'Python'
creator = table[language]
creator

for lang in table.keys():
    print(lang + '\t' + table[lang])
print("Podemos criar um dicionário como se fosse uma lista, porém sem alocar o espaço que uma lista")
print("Para isso, criamos um dicionário vazio e atribuímos spam a suposta posição 99")
 D= {}
D[99] = 'spam'
print("D[99] => %s" % D[99])
print("D => %s" % D) 

