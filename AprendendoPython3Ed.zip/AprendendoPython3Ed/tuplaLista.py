#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Tupla com lista
T = (1, [2, 3], 4)
print("Tupla com lista %s" % T)

# Alterando a lista dentro da tupla, é obrigatório indicar o índice da tupla e depois indicar o índice da lista
# Por exemplo, T[1] = 'spam' irá gerar um erro.
T[1][0] = 'spam'

print("Lista dentro da tupla alterada $s" % T)
