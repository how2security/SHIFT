#1/usr/bin/env python3
# -*- coding: utf-8 -*-

print("Comprimento => len([1,2,3])")
print(len([1,2,3]))
print("Concatenacao => [1,2,3] + [4,5,6]")
print([1,2,3] + [4,5,6])
print("Repeticao => ['TI!'] * 3")
print(['TI!'] * 3)
print("Participacao como membro => 3 in [1,2,3]")
print(3 in [1,2,3])
print("Iteracao => for x in [1,2,3]: print x")
x = 2
for x in [1,2,3]:
    print(x)
print("Deslocamentos => L = ['spam', 'Spam', 'SPAM']")
print("Os deslocamentos comecam em zero => L[2]")
L = ['spam', 'Spam', 'SPAM']
print(L[2])
print("Negativo: conta a partir da direita => L[-2]")
print(L[-2])
print("O fracionamento busca secoes => L[1:]")
print(L[1:])
print("Atribuicoes")
print("Atribuicao de indice => L[1] = 'eggs'")
L[1] = 'eggs'
print(L)
print("Atribuicao de fragmentacao => L[0:2] = ['eat', 'more']")
L[0:2] = ['eat', 'more']
print(L)
print("Atribuicao de fracionamento L2 = [1, 2, 3] => L2[1:2] = [4, 5]")
L2 = [1, 2, 3]
L2[1:2] = [4, 5]
print(L2)
print("Aqui pedimos para a parti da posição 1 e não a posição 2, por isso, foi exluido o 2 e adicionado em seu lugar o 4 e 5")
print("Por isso que se fizermos L2[1:2] = [] irá excluir o 2 da lista")
print("Anexar chamada de metodo => L.append('please')")
print("Anexar chamada de metodo => L.append('please')")
L.append('please')
print(L)
print("Ordenar os itens da lista => L.sort()")
L.sort()
print(L)
print("Tenha cuidado ao utilizar append e sort, eles alteram o objeto associado no local da lista, e não retornam o resultado a lista.")
print("Tecnicamente, ambos retornam um valor chamado None.")
print("Forma errada de anexar em uma lista L3 = [1, 2, 3] => L3=L3.append(4)")
L2 = [1, 2, 3]
print(L3)
L2=L3.append(4)
print(L3)
print("Desta forma você perde toda a referência para a lista e por isso ela volta vazia.")
print("Anexar varios itens => L=[1,2] - L.extend([3,4,5]")
L = [1,2]
L.extend([3,4,5])
print(L)
print("Exclui o ultimo item = L.pop()")
L.pop()
print(L)
print("Iversao no local => L.reverse()")
L.reverse()
print(L)
print("Excluir um item => del L[0]")
del L[0]
print(L)
print("Excluir uma secao inteira => L[1:]")
del L[1:]
print(L)
print("Matriz => matrix=[[1,2,3],[4,5,6],[7,8,9]]")
print("Matriz linha 1 => matrix[1]")
matrix = [[1,2,3],[4,5,6],[7,8,9]]
print(matrix[1])
print("Matriz indice i:j => matrix[1][1]")
print(matrix[1][1])
print(matrix[2][0])
print(matrix)

