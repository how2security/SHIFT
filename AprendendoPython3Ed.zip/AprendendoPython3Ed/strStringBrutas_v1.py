#!/usr/bin/env python3
# -*- coding: utf-8 -*-

print ("Forma errada de indicar um caminho")
myfile = ('C:\new\text.txt')
print(myfile)

print("\nIsso porque temos dois caracteres especiais o \\n e o \\t")

print("\nA forma correta e informando que iremos trabalhar com strings brutas utilizando o r antes do apostrofo\n")

myfile = (r'C:\new\text.txt')
print(myfile)
