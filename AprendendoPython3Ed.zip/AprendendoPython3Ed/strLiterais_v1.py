#!/usr/bin/env python3
# -*- coding: utf-8 -*-

print("LITERAIS EM STRINGS")
print("===================")

print("s1 = ' ' \t->\t String Vazia")
print("s2 = \"spam's\" \t->\t Aspas Duplas")
print("block = \"\"\"...\"\"\" \t->\t Blocos com aspas triplas")
print("s3 = r\'\\temp\spam\' \t->\t Strings brutas")
print("s4 = u\'spam\' \t->\t Strings Unicode")
print("s1 + s2 \t->\t Concatenacao")
print("s3 * 3 \t->\t Repeticao")
print("s2[i] \t->\t Indice")
print("s2[i:j] \t->\t Fracionamento")
print("len(s2) \t->\t Comprimento")
print("\"a \%s parrot\" \% \'dead\'\" \t->\t Formatacao de strings")
print("s2.find(\'pa\') \t->\t Chamadas de metodos string")
print("s2.replace(\'pa\', \'xx\' \t->\t Subtituicao")
print("s1.split() \t->\t Quebra de string")
print("for x in s2 \t->\t Iteracao")
print("\'m\' in s2 \t->\t Participacao como membro")
