#!/usr/bin/env python3
# -*- coding: utf-8 -*-

print("Substitui todas as ocorrencias onde tiver mm por xx")
x = "spammy"
print(x)
x = x.replace('mm', 'xx')
print(x)

y = 'aa$bb$cc$dd'
print(y)
y = y.replace('$', ' ')
print(y)

print("substituir apenas a primeira ocorrencia")
print(y)
y = y.replace(' ', '-', 1)
print(y)
y = y.replace(' ', '$PAM')
print(y)
