import converters

prog = converters.Uppercase(open('spam.txt'), open('conv_spam.txt', 'w'))
prog.process()
