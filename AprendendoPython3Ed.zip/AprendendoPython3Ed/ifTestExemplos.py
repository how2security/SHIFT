#!/usr/bin/env python3
# -*- coding: utf-8 -*-

'''
   Aqui utilizamos o if como se ele fosse um switch ou case
'''

choice = input("Enter choice: ")

if choice == 'spam':
   print(1.25)
elif choice == 'ham':
   print(1.99)
elif choice == 'eggs':
   print(0.99)
elif choice == 'bacon':
   print(1.10)
else:
   print('Bad choice')
   
'''
   Aqui podemos utilizar uma lista para ser testada para ser executada o bloco de código em if..else
'''

for key in tests:						# Para todas as chaves
   if key in itens:						# Deixa o Python procurar uma correspondência
      print(key, "was found")
   else:
      print(key, "not found!")