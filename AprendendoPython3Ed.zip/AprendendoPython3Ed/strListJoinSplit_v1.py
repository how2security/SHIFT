#!/usr/bin/env python3
# -*- coding: utf-8 -*-

print("Transformando uma string em lista")
x = 'spammy'
l = list(x)
print(l)

print("Transformando a lista em strings")
l = ''.join(l)
print(l)

print("Para o join você precisa sempre de um delimitador entre os itens")
l = ['eggs', 'suasage', 'ham', 'toast']
print(l)
print(';'.join(l))

print("O split corta uma string transformando-a em uma lista de substrings")
print("por padrao o split utiliza espaco, tabulacao ou caractere de nova linha")
print("como forma de delimitar e quebrar a cadeia de strings, porem podemos")
print("passar o delimitador")

l = 'aaa bbb ccc'
print(l)
print(l.split())

l = 'aaa;bbb;ccc;ddd'
print(l)
print(l.split(';'))
