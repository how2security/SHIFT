#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Tuple T
T = ('cc', 'aa', 'dd', 'bb')

# Criando uma lista da tuple T
tmp = list(T)

# Ordenando a lista
tmp.sort()
print("Tuple Temporaria %s" % tmp)

# Criando uma nova tupla ordenada
T = tuple(tmp)
print("Tuple ordenada %s" % T)