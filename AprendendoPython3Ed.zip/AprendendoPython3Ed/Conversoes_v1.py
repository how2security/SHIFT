#!/usr/bin/env python3
# -*- coding: utf-8 -*-

print("Conversoes de String para Inteiro e vice-versa...")
print('"s1="42" e s2 = 1')
s1 = "42"
s2 = 1
s3 = abcd

print("int(s1)+s2, s1+str(s2) e float(s1) / float(s2)")
print(int(s1)+s2, s1+str(s2), float(s1) / float(s2))
print("[1,2] + list('34')")
print([1,2] + list('34'))
print("s3 = %s em list => %s" % (s3, list(s3)))

