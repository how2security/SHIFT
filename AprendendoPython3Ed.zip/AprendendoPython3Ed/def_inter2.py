#!/usr/bin/env python3
# -*- coding: utf-8 -*-

def intersect(*args):
    res = []
    for x in args[0]:		# Percorre a primeira sequencia
        for other in args[1:]:	# para todos os outros args
            if x not in other: break 	# Item em cada uma?
        else:			# Não: sai do loop
            res.append(x)	# Sim: adiciona itens no fim
    return res

def union(*args):
    res = []
    for seq in args:            # Para todos os args
        for x in seq:           # Para todos os nós
            if not x in res:
                res.append(x)   # Adiciona novos itens resultado
    return res