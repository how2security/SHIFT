#!/usr/bin/env python3
# -*- coding: utf-8 -*-

print("STRING DE FORMATACAO")
print("-" * 20)

print("Seu uso dentro do print eh:")
print("print(\"Menu nome eh: %s e tenho %d de idade\" \% (\"well\", 30)")


print("Menu nome eh: %s e tenho %d de idade" % ("well", 30))

print("\n\n")
print("Codigos de formatacao de strings")
print("\%s \t->\t String (ou qualquer objeto")
print("\%r \t->\t s, mas usa repr() e não str()")
print("\%c \t->\t Caractere")
print("\%d \t->\t Decimal")
print("\%i \t->\t Inteiro")
print("\%u \t->\t Inteiro sem sinal")
print("\%o \t->\t Inteiro em octal")
print("\%x \t->\t Inteiro em hexadecimal")
print("\%X \t->\t x, mas imprime em maiuscula")
print("\%e \t->\t Expoente de ponto flutuante")
print("\%E \t->\t e, mas imprime em maiuscula")
print("\%f \t->\t Decimal de ponto flutuante")
print("\%g \t->\t e ou f de ponto flutuante")
print("\%% \t->\t '%' literal")
print("\%06d \t->\t Informa para completar com zeros a esquerda o decimal caso seja menor que 6 serve para %f,%e e %g")
print("\%-6d \t->\t Informa para completar com zeros a esquerda o decimal caso seja menor que 6 serve para %f,%e e %g")
print("\%2.2f \t->\t Informa para mostrar dois digitos antes do ponto e dois digitos após o ponto do número de ponto flutuante")

print("\n")
print("Exemplos")
x = 1234
print(x)
print("Inteiros: %d\t%-6d\t%06d" % (x, x, x))
x = 1.23456789
print(x)
print("Flutuante: %e | %f | %g" % (x, x, x))
print("Flutuante: %-6.2f | %05.2f | %+06.1f" % (x, x, x))

print("Formatação por referencia em um dicionário")
print("%(n)d %(x)s" % {"n" : ', "x" : "spam"})

foot = 'spam'
age = 40
print(vars())

print("Formatação por referencia em um dicionário nas variáveis")
print("%(age)d %(foot)s" % vars())