#!/usr/bin/env python3
# -*- coding: utf-8 -*-

print("OPERAÇÔES")
print("-" * 9)

S = 'spam'
print("S = %s" % S)

print("Concatenação de string 'abc' + 'def' = %s" % ('abc' + 'def'))
print("Multiplicando strings '=-' * 10 = %s" % ('=-' * 10))

print("MyJob = 'hacker' -> Vamos utilizar o for na variável")
MyJob = 'hacker'
for c in MyJob: print(c)

print("Vamos ver se a letra k está contida na variável MyJob")
ptint("k" in MyJob)
